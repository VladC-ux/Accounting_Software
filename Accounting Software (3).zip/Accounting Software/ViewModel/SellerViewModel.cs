﻿using Accounting_Software.Data.Entites;

namespace Accounting_Software.ViewModel
{
    public class SellerViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
           
    }
}
