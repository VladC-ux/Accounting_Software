﻿namespace Accounting_Software.Service
{
    public class TransactionHistoryService
    {
    }
}
