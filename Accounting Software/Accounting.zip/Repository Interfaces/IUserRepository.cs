﻿using Accounting_Software.Data.Entities;

namespace Accounting_Software.Repository_Interfaces
{
    public interface IUserRepository
    {
        decimal GetBalance(int Id);
        User GetUserById(int Id);
        bool Add(User user);
        int UserCount();
        List<User> GetAll();
        User? GetByEmail(string email);
        void Update(User user);
    }
}
