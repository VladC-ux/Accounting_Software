﻿namespace Accounting_Software.Repository_Interfaces
{
    public interface ITransactionHistoryRepository
    {
    }
}
