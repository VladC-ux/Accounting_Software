﻿namespace Accounting_Software.Repositories
{
    public class TransactionHistoryRepository
    {
    }
}
