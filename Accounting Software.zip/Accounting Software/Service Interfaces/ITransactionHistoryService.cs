﻿namespace Accounting_Software.Service_Interfaces
{
    public interface ITransactionHistoryService
    {
    }
}
