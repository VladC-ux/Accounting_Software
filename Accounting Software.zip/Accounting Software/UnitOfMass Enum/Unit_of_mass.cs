﻿namespace Accounting_Software.Enums
{
    public enum Unit_of_mass
    {
        Kg=1,
        Gram=2,
        Ml =3,
        
    }
}
